import React from "react";
import Navbar from "../components/Navbar/Navbar";
import NousContacter from "../components/NousContacter/NousContacter";

const Contact = () => {
  return (
    <div>
      <Navbar />
      <NousContacter />
      
    </div>
  );
};

export default Contact;
